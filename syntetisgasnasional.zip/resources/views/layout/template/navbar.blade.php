<div class="d-flex  justify-content-md-between" style="padding: 5px 100px; background-color: #262422">
    <div class="logo me-auto">
        <!--<h1><a href="/">Mamba</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/"><img src="img/logo/logotok.png" alt=" PT Syntesis Gas Nasional" class="img-fluid-logo"></a>
    </div>
    <div class="contact-info d-flex align-items-right mt-auto mb-auto">
        <a href="mailto:syntetisgasnasional@gmail.com">syntetisgasnasional@gmail.com </a>
        <i class="bi bi-envelope-fill" style="color: white; padding-left: 10px"></i>
    </div>
    <!--<div class="social-links d-none d-md-block">
        
            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>-->
</div>
